package com.example.demo;

	import org.springframework.kafka.annotation.KafkaListener;
	import org.springframework.stereotype.Service;

	@Service
	public class KafkaConsumerService {

	    @KafkaListener(topics = "anjumtopic")
	    public void receiveMessage(String message) {
	        System.out.println("Received message: " + message);
	    }
	}


